
import { GetStaticProps } from 'next';
import { fetchArticles } from '../lib/api';

export default function Home({ articles }: any) {
  return (
    <div style={{ padding: '2rem' }}>
      <h1>Blog</h1>
      {articles.map((article: any) => (
        <div key={article.id} style={{ marginBottom: '1.5rem' }}>
          <h2>{article.attributes.title}</h2>
          <p>{article.attributes.content}</p>
        </div>
      ))}
    </div>
  );
}

export const getStaticProps: GetStaticProps = async () => {
  const articles = await fetchArticles();
  return {
    props: {
      articles,
    },
  };
};
